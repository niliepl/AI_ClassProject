% =============================================
% SCHOLARSHIP ELIGIBILITY SYSTEM
% Prolog AI Backend
% =============================================

:- use_module(library(csv)).
:- use_module(library(lists)).

% -------------------------
% DYNAMIC DATABASE
% -------------------------
:- dynamic student/3.

% -------------------------
% CSV DATA IMPORT
% -------------------------

import_students_from_csv(Filename) :-
    format('Loading students from ~w...~n', [Filename]),
    retractall(student(_, _, _)),
    (csv_read_file(Filename, Rows, [skip_header(true)]) ->
        process_csv_rows(Rows, 1),
        format('✅ Successfully loaded students from CSV~n', [])
    ;
        format('❌ Error: Could not read CSV file ~w~n', [Filename]),
        fail
    ).

process_csv_rows([], _).
process_csv_rows([Row|Rest], Index) :-
    process_csv_row(Row, Index),
    NextIndex is Index + 1,
    process_csv_rows(Rest, NextIndex).

process_csv_row(Row, StudentID) :-
    Row =.. [row|Columns],
    create_student_id(StudentID, StudentAtom),
    
    % Extract columns based on 44-column structure
    extract_column(Columns, 7, Citizenship),        % G: Citizenship
    extract_column(Columns, 9, MuslimStatus),       % I: Muslim Status  
    extract_column(Columns, 12, Disciplinary),      % L: Disciplinary
    extract_column(Columns, 25, CGPA),              % Y: CGPA
    extract_column(Columns, 26, CreditHours),       % Z: Credit Hours
    extract_column(Columns, 29, HouseholdIncome),   % AC: Income
    extract_column(Columns, 30, Dependents),        % AD: Dependents
    extract_column(Columns, 31, Employment),        % AE: Employment
    extract_column(Columns, 32, EducationalLoan),   % AF: Loan
    extract_column(Columns, 33, ActivityLevel),     % AG: Activity
    extract_column(Columns, 34, Leadership),        % AH: Leadership
    extract_column(Columns, 42, HealthChallenges),  % AP: Health
    extract_column(Columns, 43, LivingSituation),   % AQ: Living
    extract_column(Columns, 44, Consent),           % AR: Consent
    
    % Assert facts
    assert_student_fact(StudentAtom, citizenship, Citizenship),
    assert_student_fact(StudentAtom, muslim_status, MuslimStatus),
    assert_student_fact(StudentAtom, disciplinary_record, Disciplinary),
    assert_student_fact(StudentAtom, cgpa, CGPA),
    assert_student_fact(StudentAtom, credit_hours, CreditHours),
    assert_student_fact(StudentAtom, household_income, HouseholdIncome),
    assert_student_fact(StudentAtom, dependents, Dependents),
    assert_student_fact(StudentAtom, employment_status, Employment),
    assert_student_fact(StudentAtom, educational_loan, EducationalLoan),
    assert_student_fact(StudentAtom, activity_level, ActivityLevel),
    assert_student_fact(StudentAtom, leadership_positions, Leadership),
    assert_student_fact(StudentAtom, health_challenges, HealthChallenges),
    assert_student_fact(StudentAtom, living_situation, LivingSituation),
    assert_student_fact(StudentAtom, consent, Consent).

extract_column(Columns, Index, Value) :-
    (nth1(Index, Columns, Value) -> true ; Value = 'Unknown').

create_student_id(Index, StudentAtom) :-
    format(atom(StudentAtom), 'student_~w', [Index]).

assert_student_fact(StudentID, Field, Value) :-
    (Value \= 'Unknown', Value \= '' ->
        assertz(student(StudentID, Field, Value))
    ;
        true
    ).

% -------------------------
% CORE ELIGIBILITY ENGINE
% -------------------------

determine_eligibility(StudentID, Decision, Confidence, Explanation) :-
    validate_basic_requirements(StudentID, BasicCheck),
    (BasicCheck = basic_passed ->
        evaluate_academic_profile(StudentID, AcademicTier, AcademicScore),
        evaluate_financial_need(StudentID, FinancialTier, FinancialScore),
        evaluate_cocurricular_profile(StudentID, CocurricularTier, CocurricularScore),
        evaluate_special_factors(StudentID, SpecialFlags, SpecialScore),
        calculate_composite_score(AcademicScore, FinancialScore, CocurricularScore, SpecialScore, TotalScore),
        apply_decision_rules(AcademicTier, FinancialTier, CocurricularTier, SpecialFlags, Decision),
        calculate_confidence(TotalScore, Decision, Confidence),
        generate_explanation(StudentID, AcademicTier, FinancialTier, CocurricularTier, SpecialFlags, Decision, Explanation)
    ;
        Decision = 'Not Eligible - Basic Requirements',
        Confidence = 0.0,
        Explanation = 'Failed basic eligibility criteria'
    ).

validate_basic_requirements(StudentID, basic_passed) :-
    student(StudentID, citizenship, 'Yes'),
    student(StudentID, muslim_status, 'Yes'),
    student(StudentID, disciplinary_record, 'No'),
    student(StudentID, consent, 'Yes, I agree').

validate_basic_requirements(_, basic_failed).

% Academic Evaluation
evaluate_academic_profile(StudentID, AcademicTier, TotalScore) :-
    student(StudentID, cgpa, CGPA),
    student(StudentID, credit_hours, CreditHours),
    cgpa_evaluation(CGPA, CGPATier, CGPAScore),
    credit_hours_evaluation(CreditHours, CreditTier, CreditScore),
    combine_academic_tiers(CGPATier, CreditTier, AcademicTier),
    TotalScore is CGPAScore + CreditScore.

cgpa_evaluation('3.50 – 4.00', excellent, 4.0).
cgpa_evaluation('3.00 – 3.49', good, 3.0).
cgpa_evaluation('2.50 – 2.99', average, 2.0).
cgpa_evaluation('2.00 – 2.49', weak, 1.0).

credit_hours_evaluation('Above 90', advanced, 2.0).
credit_hours_evaluation('61–90', intermediate, 1.5).
credit_hours_evaluation('30–60', beginner, 1.0).
credit_hours_evaluation('Below 30', early, 0.5).

combine_academic_tiers(excellent, _, tier1).
combine_academic_tiers(good, advanced, tier1).
combine_academic_tiers(good, intermediate, tier2).
combine_academic_tiers(good, beginner, tier2).
combine_academic_tiers(good, early, tier3).
combine_academic_tiers(average, _, tier3).
combine_academic_tiers(weak, _, tier4).

% Financial Evaluation
evaluate_financial_need(StudentID, FinancialTier, TotalScore) :-
    student(StudentID, household_income, Income),
    student(StudentID, dependents, Dependents),
    student(StudentID, employment_status, Employment),
    student(StudentID, educational_loan, Loan),
    income_evaluation(Income, IncomeTier, IncomeScore),
    dependents_evaluation(Dependents, DependentsScore),
    employment_evaluation(Employment, EmploymentScore),
    loan_evaluation(Loan, LoanScore),
    TotalScore is IncomeScore + DependentsScore + EmploymentScore + LoanScore,
    determine_financial_tier(TotalScore, FinancialTier).

income_evaluation(Income, b40, 4.0) :- sub_string(Income, _, _, _, 'B40').
income_evaluation(Income, m40, 2.0) :- sub_string(Income, _, _, _, 'M40').
income_evaluation(Income, t20, 0.0) :- sub_string(Income, _, _, _, 'T20').

dependents_evaluation('7 and above', 3.0).
dependents_evaluation('5–6', 2.0).
dependents_evaluation('3–4', 1.0).
dependents_evaluation('1–2', 0.5).

employment_evaluation('None employed', 3.0).
employment_evaluation('One employed', 2.0).
employment_evaluation('Both employed', 0.5).

loan_evaluation('Yes', 2.0).
loan_evaluation('No', 0.0).

determine_financial_tier(Score, urgent) :- Score >= 8.0.
determine_financial_tier(Score, high) :- Score >= 5.0, Score < 8.0.
determine_financial_tier(Score, medium) :- Score >= 3.0, Score < 5.0.
determine_financial_tier(Score, low) :- Score >= 1.0, Score < 3.0.
determine_financial_tier(_, minimal).

% Co-curricular Evaluation
evaluate_cocurricular_profile(StudentID, CocurricularTier, TotalScore) :-
    student(StudentID, activity_level, Activity),
    student(StudentID, leadership_positions, Leadership),
    activity_evaluation(Activity, ActivityScore),
    leadership_evaluation(Leadership, LeadershipScore),
    TotalScore is ActivityScore + LeadershipScore,
    determine_cocurricular_tier(TotalScore, CocurricularTier).

activity_evaluation('Highly active (leader/committee)', 3.0).
activity_evaluation('Very active', 2.0).
activity_evaluation('Moderately active', 1.5).
activity_evaluation('Slightly active', 1.0).
activity_evaluation('Not active', 0.0).

leadership_evaluation('Yes', 2.0).
leadership_evaluation('No', 0.0).

determine_cocurricular_tier(Score, outstanding) :- Score >= 4.5.
determine_cocurricular_tier(Score, strong) :- Score >= 3.0, Score < 4.5.
determine_cocurricular_tier(Score, moderate) :- Score >= 1.5, Score < 3.0.
determine_cocurricular_tier(Score, basic) :- Score >= 1.0, Score < 1.5).
determine_cocurricular_tier(_, poor).

% Special Factors
evaluate_special_factors(StudentID, SpecialFlags, TotalScore) :-
    findall(Flag-Score, special_factor(StudentID, Flag, Score), FlagScores),
    extract_flags(FlagScores, SpecialFlags),
    calculate_special_score(FlagScores, TotalScore).

special_factor(StudentID, health_challenge, 3.0) :-
    student(StudentID, health_challenges, 'Yes').

special_factor(StudentID, financial_hardship, 2.0) :-
    student(StudentID, living_situation, 'Off-campus'),
    student(StudentID, household_income, Income),
    sub_string(Income, _, _, _, 'B40').

extract_flags([], []).
extract_flags([Flag-_|Rest], [Flag|Flags]) :- extract_flags(Rest, Flags).

calculate_special_score([], 0).
calculate_special_score([_-Score|Rest], Total) :-
    calculate_special_score(Rest, RestTotal),
    Total is Score + RestTotal.

% Decision Rules
apply_decision_rules(tier1, urgent, outstanding, _, 'Full Scholarship').
apply_decision_rules(tier1, urgent, strong, _, 'Full Scholarship').
apply_decision_rules(tier1, high, outstanding, _, 'Full Scholarship').
apply_decision_rules(tier1, high, strong, Flags, 'Full Scholarship') :-
    member(health_challenge, Flags).

apply_decision_rules(tier1, medium, strong, _, 'Partial Scholarship').
apply_decision_rules(tier2, high, _, _, 'Partial Scholarship').
apply_decision_rules(tier2, medium, strong, _, 'Partial Scholarship').
apply_decision_rules(tier2, medium, moderate, _, 'Partial Scholarship').

apply_decision_rules(tier3, urgent, _, Flags, 'Priority Candidate') :-
    member(health_challenge, Flags).
apply_decision_rules(tier2, urgent, poor, Flags, 'Priority Candidate') :-
    member(health_challenge, Flags).

apply_decision_rules(tier4, _, _, _, 'Not Eligible').
apply_decision_rules(_, minimal, _, Flags, 'Not Eligible') :-
    \+ member(health_challenge, Flags).
apply_decision_rules(_, _, _, _, 'Not Eligible').

% Confidence Scoring
calculate_composite_score(Academic, Financial, Cocurricular, Special, Total) :-
    Total is Academic + Financial + Cocurricular + Special.

calculate_confidence(TotalScore, Decision, Confidence) :-
    max_possible_score(20),
    BaseConfidence is TotalScore / 20,
    adjust_confidence(Decision, BaseConfidence, Confidence).

max_possible_score(20).

adjust_confidence('Full Scholarship', Base, Confidence) :-
    Confidence is min(1.0, Base * 1.2).
adjust_confidence('Partial Scholarship', Base, Confidence) :-
    Confidence is min(1.0, Base * 1.1).
adjust_confidence('Priority Candidate', Base, Confidence) :-
    Confidence is Base.
adjust_confidence('Not Eligible', _, 0.1).

% Explanation
generate_explanation(StudentID, AcademicTier, FinancialTier, CocurricularTier, SpecialFlags, Decision, Explanation) :-
    format(atom(Explanation), 'Student ~w: ~w | Academic: ~w | Financial: ~w | Activities: ~w | Special: ~w', 
           [StudentID, Decision, AcademicTier, FinancialTier, CocurricularTier, SpecialFlags]).

% -------------------------
% BATCH PROCESSING
% -------------------------

evaluate_all_students(Results) :-
    findall(StudentID, student(StudentID, _, _), AllStudents),
    list_to_set(AllStudents, UniqueStudents),
    evaluate_student_list(UniqueStudents, Results).

evaluate_student_list([], []).
evaluate_student_list([StudentID|Rest], [result(StudentID, Decision, Confidence, Explanation)|Results]) :-
    (determine_eligibility(StudentID, Decision, Confidence, Explanation) ->
        true
    ;
        Decision = 'Evaluation Error',
        Confidence = 0.0,
        Explanation = 'Error processing student'
    ),
    evaluate_student_list(Rest, Results).

% -------------------------
% SYSTEM MANAGEMENT
% -------------------------

show_loaded_students :-
    findall(Student, student(Student, _, _), Students),
    list_to_set(Students, UniqueStudents),
    length(UniqueStudents, Count),
    format('Loaded ~w students:~n', [Count]),
    forall(member(Student, UniqueStudents), 
           (format('  ~w~n', [Student]))).

% Demo function
run_demo :-
    write('=== UTP SCHOLARSHIP SYSTEM DEMO ===~n~n'),
    write('1. Loading students from CSV...~n'),
    (import_students_from_csv('student_responses.csv') ->
        write('2. Showing loaded students...~n'),
        show_loaded_students,
        write('3. Evaluating all students...~n~n'),
        evaluate_all_students(Results),
        write('=== RESULTS ===~n~n'),
        print_results(Results),
        write('~n=== DEMO COMPLETE ===~n')
    ;
        write('❌ Demo failed - could not load CSV file~n')
    ).

print_results([]).
print_results([result(StudentID, Decision, Confidence, Explanation)|Rest]) :-
    format('~w: ~w (Confidence: ~2f)~n', [StudentID, Decision, Confidence]),
    format('  Explanation: ~w~n~n', [Explanation]),
    print_results(Rest).

% Helper predicates
list_to_set([], []).
list_to_set([H|T], [H|T1]) :-
    remove_all(H, T, T2),
    list_to_set(T2, T1).

remove_all(_, [], []).
remove_all(X, [X|T], T1) :- remove_all(X, T, T1).
remove_all(X, [Y|T], [Y|T1]) :- X \= Y, remove_all(X, T, T1).