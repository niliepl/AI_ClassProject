# scholarship_system.py
import pandas as pd
import os

print("🚀 UTP Scholarship System - Pure Python Version")
print("=" * 50)

# Check if CSV exists
if not os.path.exists("student_responses.csv"):
    print("❌ student_responses.csv not found!")
    print("📁 Files in current folder:", [f for f in os.listdir('.') if f.endswith('.csv')])
    exit()

# Try different encodings - Windows often uses these
encodings_to_try = ['latin-1', 'cp1252', 'iso-8859-1', 'utf-8']

df = None
used_encoding = None

for encoding in encodings_to_try:
    try:
        print(f"🔄 Trying encoding: {encoding}")
        df = pd.read_csv("student_responses.csv", encoding=encoding)
        used_encoding = encoding
        print(f"✅ Successfully loaded with {encoding} encoding!")
        break
    except Exception as e:
        print(f"❌ Failed with {encoding}: {str(e)[:100]}...")
        continue

if df is None:
    print("❌ Could not load CSV with any encoding!")
    print("💡 Let's try a different approach...")
    
    # Try reading as binary and converting
    try:
        with open("student_responses.csv", 'rb') as f:
            content = f.read()
            # Try to decode with common encodings
            for encoding in ['latin-1', 'cp1252', 'utf-8']:
                try:
                    text = content.decode(encoding)
                    # Write temporary file
                    with open('temp_fixed.csv', 'w', encoding='utf-8') as f2:
                        f2.write(text)
                    df = pd.read_csv('temp_fixed.csv')
                    used_encoding = encoding
                    print(f"✅ Fixed CSV using {encoding} encoding!")
                    break
                except:
                    continue
    except Exception as e:
        print(f"❌ Complete failure: {e}")
        exit()

if df is None:
    print("❌ Could not process your CSV file.")
    print("💡 Please save your CSV as UTF-8 in Excel/Google Sheets and try again.")
    exit()

print(f"✅ Loaded {len(df)} students using {used_encoding} encoding")

# Show what we found
print(f"\n📊 CSV Structure:")
print(f"   Rows: {len(df)}")
print(f"   Columns: {len(df.columns)}")
print(f"   Column names: {list(df.columns)}")

results = []
print(f"\n🔍 Evaluating {len(df)} students...")

for i, row in df.iterrows():
    student_id = f"student_{i+1}"
    
    try:
        # Extract data - try multiple column access methods
        try:
            # Method 1: By position (if columns are in expected order)
            citizenship = str(row.iloc[6]) if len(row) > 6 else 'No'
            muslim = str(row.iloc[8]) if len(row) > 8 else 'No'
            disciplinary = str(row.iloc[11]) if len(row) > 11 else 'Yes'
            cgpa = str(row.iloc[24]) if len(row) > 24 else '2.00 – 2.49'
            income = str(row.iloc[28]) if len(row) > 28 else 'Unknown'
            activity = str(row.iloc[32]) if len(row) > 32 else 'Not active'
            leadership = str(row.iloc[33]) if len(row) > 33 else 'No'
            health = str(row.iloc[41]) if len(row) > 41 else 'No'
            consent = str(row.iloc[43]) if len(row) > 43 else 'No'
        except:
            # Method 2: Try to find columns by name patterns
            citizenship = 'No'
            muslim = 'No'
            disciplinary = 'Yes'
            cgpa = '2.00 – 2.49'
            income = 'Unknown'
            activity = 'Not active'
            leadership = 'No'
            health = 'No'
            consent = 'No'
            
            for col_name, value in row.items():
                col_str = str(col_name).lower()
                val_str = str(value)
                
                if 'citizen' in col_str:
                    citizenship = val_str
                elif 'muslim' in col_str:
                    muslim = val_str
                elif 'disciplinary' in col_str:
                    disciplinary = val_str
                elif 'cgpa' in col_str:
                    cgpa = val_str
                elif 'income' in col_str:
                    income = val_str
                elif 'active' in col_str and 'co' in col_str:
                    activity = val_str
                elif 'leadership' in col_str:
                    leadership = val_str
                elif 'health' in col_str:
                    health = val_str
                elif 'consent' in col_str:
                    consent = val_str
        
        # Clean data
        citizenship = str(citizenship).strip()
        muslim = str(muslim).strip()
        disciplinary = str(disciplinary).strip()
        cgpa = str(cgpa).strip()
        income = str(income).strip()
        activity = str(activity).strip()
        leadership = str(leadership).strip()
        health = str(health).strip()
        consent = str(consent).strip()
        
        # Show first student's data for debugging
        if i == 0:
            print(f"\n🔍 First student data sample:")
            print(f"   Citizenship: {citizenship}")
            print(f"   Muslim: {muslim}")
            print(f"   Disciplinary: {disciplinary}")
            print(f"   CGPA: {cgpa}")
            print(f"   Income: {income}")
            print(f"   Activity: {activity}")
            print(f"   Leadership: {leadership}")
            print(f"   Health: {health}")
            print(f"   Consent: {consent}")
        
        # Basic eligibility check
        if citizenship != 'Yes' or muslim != 'Yes' or disciplinary != 'No' or consent != 'Yes, I agree':
            results.append({
                'StudentID': student_id,
                'Decision': 'Not Eligible - Basic Requirements',
                'Confidence': 0.0,
                'Explanation': 'Failed basic eligibility criteria'
            })
            continue
        
        # Academic scoring
        if '3.50' in cgpa or '4.00' in cgpa:
            academic_tier = 'tier1'
            academic_score = 4.0
        elif '3.00' in cgpa or '3.49' in cgpa:
            academic_tier = 'tier2'
            academic_score = 3.0
        elif '2.50' in cgpa or '2.99' in cgpa:
            academic_tier = 'tier3'
            academic_score = 2.0
        else:
            academic_tier = 'tier4'
            academic_score = 1.0
        
        # Financial scoring
        if 'B40' in income:
            financial_tier = 'high'
            financial_score = 4.0
        elif 'M40' in income:
            financial_tier = 'medium'
            financial_score = 2.0
        else:
            financial_tier = 'minimal'
            financial_score = 0.0
        
        # Activity scoring
        if 'Highly' in activity:
            activity_tier = 'outstanding'
            activity_score = 3.0
        elif 'Very' in activity:
            activity_tier = 'strong'
            activity_score = 2.0
        elif 'Moderately' in activity:
            activity_tier = 'moderate'
            activity_score = 1.5
        elif 'Slightly' in activity:
            activity_tier = 'basic'
            activity_score = 1.0
        else:
            activity_tier = 'poor'
            activity_score = 0.0
        
        # Leadership bonus
        if 'Yes' in leadership:
            activity_score += 2.0
        
        # Special factors
        special_flags = []
        special_score = 0.0
        
        if 'Yes' in health:
            special_flags.append('health_challenge')
            special_score += 3.0
        
        # Total score
        total_score = academic_score + financial_score + activity_score + special_score
        
        # Decision rules
        if academic_tier == 'tier1' and financial_tier == 'high' and activity_tier in ['outstanding', 'strong']:
            decision = 'Full Scholarship'
            confidence = min(1.0, (total_score / 20) * 1.2)
        elif academic_tier in ['tier1', 'tier2'] and financial_tier in ['medium', 'high']:
            decision = 'Partial Scholarship'
            confidence = min(1.0, (total_score / 20) * 1.1)
        elif 'health_challenge' in special_flags and financial_tier != 'minimal':
            decision = 'Priority Candidate'
            confidence = total_score / 20
        else:
            decision = 'Not Eligible'
            confidence = 0.1
        
        explanation = f"Academic: {academic_tier}, Financial: {financial_tier}, Activities: {activity_tier}, Special: {special_flags}"
        
        results.append({
            'StudentID': student_id,
            'Decision': decision,
            'Confidence': round(confidence, 2),
            'Explanation': explanation
        })
        
    except Exception as e:
        results.append({
            'StudentID': student_id, 
            'Decision': 'Evaluation Error',
            'Confidence': 0.0,
            'Explanation': f'Error: {str(e)}'
        })

# Display results
print(f"\n🎓 EVALUATION RESULTS ({len(results)} students)")
print("=" * 70)

full_count = partial_count = priority_count = not_eligible = error_count = 0

for result in results:
    decision = result['Decision']
    confidence = result['Confidence']
    
    if 'Full Scholarship' in decision:
        emoji = '🟢'
        full_count += 1
    elif 'Partial Scholarship' in decision:
        emoji = '🟡'
        partial_count += 1
    elif 'Priority Candidate' in decision:
        emoji = '🟠'
        priority_count += 1
    elif 'Error' in decision:
        emoji = '⚫'
        error_count += 1
    else:
        emoji = '🔴'
        not_eligible += 1
    
    print(f"{emoji} {result['StudentID']}: {decision}")
    print(f"   📊 Confidence: {confidence:.2f}")
    print(f"   📝 {result['Explanation']}")

# Statistics
print(f"\n📈 SYSTEM STATISTICS")
print("=" * 70)
print(f"Total Students: {len(results)}")
print(f"🟢 Full Scholarships: {full_count}")
print(f"🟡 Partial Scholarships: {partial_count}")
print(f"🟠 Priority Candidates: {priority_count}")
print(f"🔴 Not Eligible: {not_eligible}")
if error_count > 0:
    print(f"⚫ Errors: {error_count}")

# Save results
output_df = pd.DataFrame(results)
output_df.to_csv('scholarship_results.csv', index=False, encoding='utf-8')
print(f"\n💾 Results saved to 'scholarship_results.csv'")
print("✅ System completed successfully!")

# Clean up temporary file
if os.path.exists('temp_fixed.csv'):
    os.remove('temp_fixed.csv')